<?php
	$metas = array(
		"mal" => array(
			"title" => "Adivina Juan",
			"description" => "Claramente no sabes ni lo que es un balón… mejor dedícate al box, al póker o qué sé yo",
			"image" => "images/resultados-1.jpg" 
		),
		"maso" => array(
			"title" => "Adivina Juan",
			"description" => "Mñeh, pudiste salir mejor. Ni muy muy, ni tan tan. Échale más ganitas. Sí se puede.",
			"image" => "images/resultados-2.jpg" 
		),
		"bien" => array(
			"title" => "Adivina Juan",
			"description" => "¡Eres un D10S! ¡El balón y tú son uno mismo!",
			"image" => "images/resultados-3.jpg" 
		)
	);